# jQuery Dist

This repo only contains package distribution files for jQuery Core.

For source files and issues, visit the [jQuery repo](https://github.com/jquery/jquery).
